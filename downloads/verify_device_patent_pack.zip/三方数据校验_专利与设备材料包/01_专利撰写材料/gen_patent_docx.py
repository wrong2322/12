#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""生成取水计量三方校验加装装置专利申请撰写材料（Word）。"""

from __future__ import annotations

from pathlib import Path

from PIL import Image, ImageDraw, ImageFont
from docx import Document
from docx.enum.text import WD_ALIGN_PARAGRAPH, WD_LINE_SPACING
from docx.oxml.ns import qn
from docx.shared import Cm, Pt, Inches

OUT_DIR = Path("/home/ubuntu/Desktop")
FIG_DIR = Path("/workspace/private/patent_out/figures")
ALT_DIR = Path("/workspace/private/patent_out")


def font(size: int):
    for p in (
        "/usr/share/fonts/truetype/wqy/wqy-zenhei.ttc",
        "/usr/share/fonts/truetype/wqy/wqy-microhei.ttc",
        "/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc",
        "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf",
    ):
        if Path(p).exists():
            try:
                return ImageFont.truetype(p, size)
            except Exception:
                continue
    return ImageFont.load_default()


def new_canvas(w=1600, h=1100):
    img = Image.new("RGB", (w, h), "white")
    draw = ImageDraw.Draw(img)
    return img, draw


def box(draw, xy, text, f, pad=8):
    x1, y1, x2, y2 = xy
    draw.rectangle(xy, outline="black", width=2)
    # center text roughly
    tw, th = draw.textbbox((0, 0), text, font=f)[2:]
    cx = (x1 + x2 - tw) / 2
    cy = (y1 + y2 - th) / 2
    draw.text((cx, cy), text, fill="black", font=f)


def arrow(draw, start, end):
    draw.line([start, end], fill="black", width=2)
    x1, y1 = start
    x2, y2 = end
    import math

    ang = math.atan2(y2 - y1, x2 - x1)
    L = 12
    for da in (2.5, -2.5):
        ax = x2 - L * math.cos(ang + da)
        ay = y2 - L * math.sin(ang + da)
        draw.line([(x2, y2), (ax, ay)], fill="black", width=2)


def fig1_system():
    img, d = new_canvas()
    f, fs, ft = font(28), font(22), font(20)
    d.text((40, 20), "图1  取水计量三方数据校验加装装置结构示意图", fill="black", font=f)

    # pipe
    d.rectangle((80, 180, 780, 230), outline="black", width=3)
    d.text((90, 145), "取水管道", fill="black", font=fs)

    box(d, (200, 155, 310, 255), "原流量计\n1", f)
    box(d, (480, 120, 620, 170), "外夹核查传感器 2", fs)
    d.text((480, 250), "旁路独立计量通道", fill="black", font=ft)

    box(d, (200, 340, 330, 420), "原遥测终端\nRTU 4", fs)
    arrow(d, (255, 255), (255, 340))
    d.text((270, 290), "原监测链路", fill="black", font=ft)

    box(d, (380, 350, 560, 430), "故障直通\n只听分接单元 3", fs)
    # tap from meter-RTU line
    d.line([(255, 300), (380, 390)], fill="black", width=2)
    arrow(d, (560, 390), (650, 390))

    box(d, (650, 300, 980, 520), "", f)
    d.text((700, 320), "校验控制器 5", fill="black", font=f)
    box(d, (680, 370, 950, 420), "同步采集与对账模块 51", fs)
    box(d, (680, 440, 950, 490), "存储与事件输出模块 52", fs)

    arrow(d, (550, 170), (750, 300))
    d.text((600, 200), "方①独立计量", fill="black", font=ft)
    d.text((570, 450), "方②监测镜像", fill="black", font=ft)

    box(d, (1100, 120, 1500, 260), "业务数据接口 6\n直报水量/纳税水量\n许可配额摘要", fs)
    arrow(d, (1100, 200), (980, 360))
    d.text((1120, 280), "方③业务水量", fill="black", font=ft)

    box(d, (1100, 340, 1500, 420), "原监测平台（保持不变）", fs)
    d.line([(255, 420), (255, 480), (1100, 380)], fill="black", width=2)

    box(d, (1100, 460, 1500, 540), "校验事件/工单线索输出", fs)
    arrow(d, (980, 480), (1100, 500))

    d.text((80, 980), "注：原流量计至原遥测终端的主链路经只听分接单元旁听；分接单元故障时主链路硬件直通。", fill="black", font=ft)
    path = FIG_DIR / "fig1.png"
    img.save(path)
    return path


def fig2_tap():
    img, d = new_canvas(1600, 900)
    f, fs, ft = font(28), font(22), font(20)
    d.text((40, 20), "图2  故障直通只听分接单元原理示意图", fill="black", font=f)

    box(d, (80, 200, 280, 320), "原流量计\n通信输出", fs)
    box(d, (1200, 200, 1480, 320), "原遥测终端\nRTU", fs)

    # main path through bypass relay
    box(d, (400, 160, 980, 360), "", f)
    d.text((560, 175), "只听分接单元 3", fill="black", font=f)
    box(d, (450, 230, 650, 310), "旁路继电器\n（失电直通）", fs)
    box(d, (700, 230, 930, 310), "光电/磁耦\n隔离旁听电路", fs)

    arrow(d, (280, 260), (450, 260))
    arrow(d, (650, 260), (700, 260))
    # direct through when relay closed - show line to RTU
    d.line([(650, 200), (1100, 200), (1100, 260)], fill="black", width=2)
    arrow(d, (1100, 260), (1200, 260))
    d.text((900, 170), "主链路直通触点", fill="black", font=ft)

    box(d, (700, 450, 1000, 560), "校验控制器 5\n旁听输入", fs)
    arrow(d, (815, 310), (815, 450))
    d.text((830, 380), "只听，不占用主站", fill="black", font=ft)

    d.text((80, 650), "工作说明：", fill="black", font=fs)
    d.text((80, 700), "1. 正常供电时，隔离旁听电路高阻监听原表至RTU的通信帧或脉冲/电流信号，并送入校验控制器；", fill="black", font=ft)
    d.text((80, 745), "2. 旁听电路与主链路电气隔离，不改变原遥测终端的轮询与上报；", fill="black", font=ft)
    d.text((80, 790), "3. 失电或故障时，旁路继电器闭合，原流量计与原遥测终端硬件直通，保证原监测链路可用。", fill="black", font=ft)
    path = FIG_DIR / "fig2.png"
    img.save(path)
    return path


def fig3_flow():
    img, d = new_canvas(1400, 1500)
    f, fs, ft = font(28), font(22), font(20)
    d.text((40, 20), "图3  三方数据校验方法流程图", fill="black", font=f)

    steps = [
        (200, 80, 900, 150, "S1  采集旁路独立计量通道的瞬时/累计水量 Q1"),
        (200, 200, 900, 270, "S2  经只听分接同步采集原监测镜像水量 Q2"),
        (200, 320, 900, 390, "S3  接收业务周期内直报水量 Q3a、纳税水量 Q3b\n及许可配额约束"),
        (200, 440, 900, 510, "S4  在统一时基下计算 Q1 与 Q2 的一致性偏差 δ12"),
        (200, 560, 900, 650, "S5  在业务周期容差窗内计算 Q1（或审定Q2）\n相对 Q3a/Q3b 的偏差 δ13、δ23"),
        (200, 700, 900, 770, "S6  将 δ 与预设阈值比较，并结合许可/证照状态判别"),
        (200, 820, 900, 890, "S7  超阈或强制违规时生成校验事件与处置出口建议"),
        (200, 940, 900, 1010, "S8  本地存储证据摘要并输出事件（可选上报摘要）"),
    ]
    for i, (x1, y1, x2, y2, t) in enumerate(steps):
        box(d, (x1, y1, x2, y2), t, fs if "\n" not in t else ft)
        if i < len(steps) - 1:
            arrow(d, ((x1 + x2) / 2, y2), ((x1 + x2) / 2, steps[i + 1][1]))

    # decision diamond-ish
    box(d, (980, 700, 1320, 820), "是否超过阈值\n或强制违规？", fs)
    d.line([(900, 735), (980, 760)], fill="black", width=2)
    d.text((1100, 840), "是→S7", fill="black", font=ft)
    d.text((980, 650), "否→继续监测", fill="black", font=ft)

    path = FIG_DIR / "fig3.png"
    img.save(path)
    return path


def fig4_controller():
    img, d = new_canvas(1500, 1000)
    f, fs, ft = font(28), font(22), font(20)
    d.text((40, 20), "图4  校验控制器模块组成框图", fill="black", font=f)

    box(d, (80, 200, 320, 320), "独立计量\n输入接口", fs)
    box(d, (80, 380, 320, 500), "监测镜像\n输入接口", fs)
    box(d, (80, 560, 320, 680), "业务数据\n接口", fs)

    box(d, (450, 280, 900, 620), "", f)
    d.text((560, 300), "校验控制器 5", fill="black", font=f)
    box(d, (500, 360, 850, 430), "时钟同步单元", fs)
    box(d, (500, 450, 850, 520), "偏差计算与规则判别单元", fs)
    box(d, (500, 540, 850, 600), "事件生成与存储单元", fs)

    arrow(d, (320, 260), (450, 400))
    arrow(d, (320, 440), (450, 460))
    arrow(d, (320, 620), (450, 560))

    box(d, (1100, 300, 1420, 400), "人机/导出接口", fs)
    box(d, (1100, 450, 1420, 550), "事件通信接口", fs)
    box(d, (1100, 600, 1420, 700), "开箱/铅封告警", fs)
    arrow(d, (900, 400), (1100, 350))
    arrow(d, (900, 500), (1100, 500))
    arrow(d, (900, 580), (1100, 650))

    path = FIG_DIR / "fig4.png"
    img.save(path)
    return path


def set_run_font(run, name="宋体", size=12, bold=False):
    run.font.size = Pt(size)
    run.font.bold = bold
    run.font.name = name
    r = run._element
    r.rPr.rFonts.set(qn("w:eastAsia"), name)


def add_para(doc, text, size=12, bold=False, first_line=True, center=False, space_after=6):
    p = doc.add_paragraph()
    pf = p.paragraph_format
    pf.space_after = Pt(space_after)
    pf.line_spacing_rule = WD_LINE_SPACING.ONE_POINT_FIVE
    if first_line and not center:
        pf.first_line_indent = Cm(0.74)
    if center:
        p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    run = p.add_run(text)
    set_run_font(run, size=size, bold=bold)
    return p


def add_heading_cn(doc, text, size=16):
    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p.paragraph_format.space_before = Pt(12)
    p.paragraph_format.space_after = Pt(12)
    run = p.add_run(text)
    set_run_font(run, name="黑体", size=size, bold=True)
    return p


def add_section_title(doc, text):
    p = doc.add_paragraph()
    p.paragraph_format.space_before = Pt(10)
    p.paragraph_format.space_after = Pt(6)
    run = p.add_run(text)
    set_run_font(run, name="黑体", size=14, bold=True)
    return p


def add_figure(doc, path: Path, caption: str):
    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    run = p.add_run()
    run.add_picture(str(path), width=Cm(15.5))
    cap = doc.add_paragraph()
    cap.alignment = WD_ALIGN_PARAGRAPH.CENTER
    r = cap.add_run(caption)
    set_run_font(r, size=10.5)


def build_doc(figs: dict[str, Path]) -> Path:
    doc = Document()
    section = doc.sections[0]
    section.page_width = Cm(21.0)
    section.page_height = Cm(29.7)
    section.left_margin = Cm(2.5)
    section.right_margin = Cm(2.5)
    section.top_margin = Cm(2.5)
    section.bottom_margin = Cm(2.5)

    # ===== 封面信息 =====
    add_heading_cn(doc, "专利申请撰写材料（内部稿）", 18)
    add_para(doc, "发明名称：一种取水计量三方数据校验加装装置及校验方法", size=14, bold=True, first_line=False, center=True)
    add_para(doc, "文档性质：权利要求书、说明书、说明书摘要及附图（用于委托代理机构正式申报前的技术交底与内部定稿）", size=10.5, first_line=False, center=True)
    add_para(doc, "说明：本文按发明专利常用体例撰写；附图为说明图，正式递交前可由代理机构按制图规范重绘为线条图。", size=10.5, first_line=False, center=True)

    # ===== 权利要求书 =====
    doc.add_page_break()
    add_heading_cn(doc, "权 利 要 求 书", 16)

    claims = [
        (
            "1. 一种取水计量三方数据校验加装装置，用于加装在已设置原流量计（1）和原遥测终端（4）的取水计量点，其特征在于，包括：",
            "旁路独立计量通道，含固定安装在取水管道外壁的外夹式核查传感器（2）及与之连接的积算单元，用于获得独立于原流量计（1）的第一水量数据Q1；\n"
            "故障直通只听分接单元（3），串接于原流量计（1）与原遥测终端（4）之间的原监测链路上，用于旁听获得第二水量数据Q2，并在失电或故障时使原监测链路硬件直通；\n"
            "校验控制器（5），分别连接所述积算单元和所述只听分接单元（3），用于在统一时基下对Q1与Q2进行一致性比对；\n"
            "业务数据接口（6），连接所述校验控制器（5），用于接收业务周期内的直报水量Q3a和/或纳税水量Q3b以及许可配额约束数据；\n"
            "所述校验控制器（5）还用于在设定的业务周期容差窗内计算Q1或经一致性判定后的Q2相对Q3a、Q3b的偏差，并在偏差超过预设阈值或触发强制违规条件时生成校验事件。",
        ),
        (
            "2. 根据权利要求1所述的装置，其特征在于，所述只听分接单元（3）包括：",
            "主链路旁路继电器，配置为失电闭合以实现原流量计（1）与原遥测终端（4）之间的硬件直通；\n"
            "隔离旁听电路，经光电耦合或磁耦隔离后连接所述校验控制器（5），用于在高阻旁听状态下采集通信帧、脉冲信号或模拟电流信号中的至少一种。",
        ),
        (
            "3. 根据权利要求1所述的装置，其特征在于，所述校验控制器（5）包括时钟同步单元、偏差计算与规则判别单元、事件生成与存储单元；所述时钟同步单元用于为Q1、Q2提供统一采样节拍。",
            "",
        ),
        (
            "4. 根据权利要求1所述的装置，其特征在于，所述预设阈值包括相对偏差阈值，默认相对偏差阈值为5%；所述强制违规条件包括计量水量超过许可配额分摊量、统计申报水量超过许可配额分摊量、许可证照失效仍存在取水计量数据中的至少一种。",
            "",
        ),
        (
            "5. 根据权利要求1所述的装置，其特征在于，所述业务数据接口（6）接收的数据为结构化摘要数据，不包括税务票面原文或申报附件原文；所述校验控制器（5）默认仅输出校验事件摘要，不向外发送原始采样波形。",
            "",
        ),
        (
            "6. 根据权利要求1所述的装置，其特征在于，所述外夹式核查传感器（2）的安装方位与原流量计（1）的传感器安装方位在管道周向上相互错开，且所述旁路独立计量通道与原流量计（1）电气隔离。",
            "",
        ),
        (
            "7. 根据权利要求1所述的装置，其特征在于，所述校验控制器（5）还连接开箱检测开关和/或电子铅封模块，用于在箱体被打开时记录告警事件。",
            "",
        ),
        (
            "8. 一种取水计量三方数据校验方法，采用权利要求1至7任一项所述的装置实现，其特征在于，包括以下步骤：",
            "S1，由旁路独立计量通道采集第一水量数据Q1；\n"
            "S2，由故障直通只听分接单元（3）同步采集原监测链路的第二水量数据Q2；\n"
            "S3，经业务数据接口（6）获取业务周期内的直报水量Q3a和/或纳税水量Q3b，以及许可配额约束数据；\n"
            "S4，在统一时基下计算Q1与Q2的一致性偏差δ12；\n"
            "S5，在业务周期容差窗内计算Q1或经一致性判定后的Q2相对Q3a、Q3b的偏差δ13、δ23；\n"
            "S6，当δ12、δ13、δ23中任一项超过预设阈值，或满足强制违规条件时，生成校验事件并给出处置出口类型；\n"
            "S7，将校验事件与对应时段的水量摘要本地存储，并按配置输出。",
        ),
        (
            "9. 根据权利要求8所述的方法，其特征在于，所述处置出口类型包括：更正直报数据、提请税基复核、调整许可或计划用水指标、整改计量设施或信号链路、标记检修停运中的一种或多种；对于强制违规条件触发的事件，禁止仅以文字情况说明作为唯一关闭方式。",
            "",
        ),
        (
            "10. 根据权利要求8所述的方法，其特征在于，当δ12超过阈值且管道侧Q1连续有效时，将事件优先判定为原监测链路异常或原流量计示值异常；当δ12未超阈值而δ13或δ23超过阈值时，将事件优先判定为直报或纳税水量与计量水量不一致。",
            "",
        ),
    ]

    for head, body in claims:
        add_para(doc, head, first_line=False, space_after=3)
        if body:
            for line in body.split("\n"):
                add_para(doc, line, first_line=True, space_after=3)

    # ===== 说明书 =====
    doc.add_page_break()
    add_heading_cn(doc, "说 明 书", 16)
    add_para(doc, "一种取水计量三方数据校验加装装置及校验方法", size=14, bold=True, first_line=False, center=True)

    add_section_title(doc, "技术领域")
    add_para(
        doc,
        "本发明属于取水计量与用水数据质量管理技术领域，具体涉及一种可固定加装于取水计量点的三方数据校验装置，以及基于该装置的校验方法。",
    )

    add_section_title(doc, "背景技术")
    add_para(
        doc,
        "规模以上自备取水和公共供水取水口普遍配置了原流量计及遥测终端，监测数据可上传至水资源监测系统。与此同时，取用水户还需进行用水统计直报，并按照水资源税征管要求申报纳税水量。许可管理中的取水配额与证照状态，对取水行为构成法定约束。",
    )
    add_para(
        doc,
        "实践中存在三类常见问题：一是原流量计出现跳变、离线、故障或参数失准，导致“有监测数据”但监测数据不可用；二是原流量计现场示值与遥测上传值不一致，链路环节异常难以及时发现；三是直报水量、纳税水量与计量水量在同一业务周期内相对偏差较大，又缺乏固定在现场、可持续运行的自动闭合手段。现有便携式外夹超声波流量计主要用于人工到场比测，属于抽检快照，难以支撑日常连续校验。现有遥测终端主要用于数据采集远传，并不具备将独立核查计量、原监测镜像与直报/纳税业务水量在本地自动对账并生成校验事件的能力。",
    )
    add_para(
        doc,
        "因此，需要一种不依赖拆除原表、尽量不影响原监测远传、可常驻加装的装置，在取水点持续获得相互独立的计量信息与业务水量信息，并自动完成三方校验。",
    )

    add_section_title(doc, "发明内容")
    add_para(doc, "本发明要解决的技术问题是：如何在保留原流量计和原遥测终端的前提下，通过现场加装设备，持续获得独立核查水量、原监测镜像水量和直报/纳税业务水量，并自动判别偏差与强制违规。", first_line=True)
    add_para(doc, "为解决上述问题，本发明提供如下技术方案。", first_line=True)

    add_para(doc, "一方面，提供一种取水计量三方数据校验加装装置，包括旁路独立计量通道、故障直通只听分接单元、校验控制器和业务数据接口。旁路独立计量通道通过固定安装的外夹式核查传感器获得第一水量数据Q1；只听分接单元串接在原流量计与原遥测终端之间，旁听得到第二水量数据Q2，并在失电或故障时使原监测链路硬件直通；业务数据接口向校验控制器提供直报水量Q3a和/或纳税水量Q3b及许可配额约束；校验控制器在统一时基下比对Q1与Q2，并在业务周期容差窗内计算相对业务水量的偏差，超阈值或触发强制违规时生成校验事件。", first_line=True)

    add_para(doc, "另一方面，提供一种采用上述装置的校验方法，包括同步采集Q1、Q2，接收Q3a/Q3b与许可约束，计算一致性偏差与业务偏差，生成并存储校验事件等步骤。", first_line=True)

    add_para(doc, "本发明的有益效果在于：", first_line=True)
    add_para(doc, "（1）加装旁路独立计量通道，可不破管、不停水获得与原表电气隔离的第一水量，避免仅依赖原监测数据；", first_line=True)
    add_para(doc, "（2）采用故障直通只听分接，能够旁听原监测链路真实输出，并在加装装置失电时不影响原遥测远传；", first_line=True)
    add_para(doc, "（3）将独立计量、监测镜像与直报/纳税水量在同一控制器内按周期闭合，可区分“表具/链路异常”与“申报口径不一致”；", first_line=True)
    add_para(doc, "（4）校验在现场连续运行，输出事件级结果，适用于日常管理校验，而非一次性到场比测。", first_line=True)

    add_section_title(doc, "附图说明")
    add_para(doc, "图1为本发明实施例提供的取水计量三方数据校验加装装置结构示意图；", first_line=False)
    add_para(doc, "图2为故障直通只听分接单元原理示意图；", first_line=False)
    add_para(doc, "图3为本发明实施例提供的三方数据校验方法流程图；", first_line=False)
    add_para(doc, "图4为校验控制器模块组成框图。", first_line=False)
    add_para(doc, "图中：1—原流量计；2—外夹式核查传感器；3—故障直通只听分接单元；4—原遥测终端；5—校验控制器；6—业务数据接口；51—同步采集与对账模块；52—存储与事件输出模块。", first_line=False)

    add_section_title(doc, "具体实施方式")
    add_para(
        doc,
        "下面结合附图对本发明实施例作具体说明。本实施例用于解释技术方案，并不限定保护范围。",
    )
    add_para(
        doc,
        "参见图1，本实施例的加装装置安装于已具备原流量计1和原遥测终端4的取水计量点。外夹式核查传感器2以抱箍方式固定在取水管道外壁，经积算单元形成旁路独立计量通道，输出第一水量数据Q1。传感器2与原流量计1在管道周向上错开安装，二者电气隔离。",
    )
    add_para(
        doc,
        "参见图1和图2，故障直通只听分接单元3串接于原流量计1至原遥测终端4的原监测链路中。正常工作时，隔离旁听电路高阻监听通信总线、脉冲或4～20mA信号，得到第二水量数据Q2并送入校验控制器5；原遥测终端4仍按原方式向上游监测平台报送，本发明不替换原远传通道。当只听分接单元3失电或检测到故障时，旁路继电器闭合，原流量计1与原遥测终端4硬件直通，保证原监测可用。",
    )
    add_para(
        doc,
        "校验控制器5安装于计量井旁或泵房壁挂箱内，包括时钟同步单元、偏差计算与规则判别单元、事件生成与存储单元（参见图4）。时钟同步单元为Q1、Q2提供统一采样节拍，例如1次/秒或1次/分钟，并形成日累计、月累计。业务数据接口6用于接收县级汇聚系统下发或巡检写入的结构化摘要，至少包括：统计直报水量Q3a、纳税水量Q3b、税期或统计周期标识、许可年取水配额或计划用水指标、证照有效状态。接口6不要求接入税务票面原文。",
    )
    add_para(
        doc,
        "参见图3，校验方法流程如下。",
    )
    add_para(
        doc,
        "步骤S1～S2：同步获取Q1、Q2。计算相对偏差δ12＝|Q1－Q2|/max(|Q1|,|Q2|,ε)。若δ12超过阈值（例如5%）且Q1连续有效，则生成“原监测链路或原流量计异常”类事件，提示检查表计、信号或遥测终端。",
    )
    add_para(
        doc,
        "步骤S3～S5：在业务周期容差窗内对齐Q3a、Q3b。容差窗用于吸收抄表日、监测累计日、税期不完全一致带来的错位，可配置为若干天。计算δ13、δ23；当任一项超过阈值，生成“直报或纳税水量与计量水量不一致”类事件。",
    )
    add_para(
        doc,
        "步骤S6～S7：结合许可配额分摊量（例如按月为年配额的1/12，按季为1/4，具体以计划用水指标为准）判断是否计量超许可或统计超许可；若证照状态为失效仍采集到取水增量，生成强制违规事件。事件记录中给出处置出口类型，例如更正直报、提请税基复核、调整许可或计划、整改计量设施或信号、标记检修停运。强制违规事件不得仅以文字说明关闭。",
    )
    add_para(
        doc,
        "步骤S8：事件与对应时段水量摘要写入本地加密存储，保存期限按管理需要设置（例如不少于12个月）。可配置为仅本地导出，或仅上报事件摘要；默认不发送原始声波波形或完整通信报文。",
    )
    add_para(
        doc,
        "在公共供水取水口实施例中，业务数据接口6或校验控制器5可增加转供转入水量、转供转出水量输入，用于辅助判断县域水量闭合不平衡，其偏差计算方式与上述相对偏差相同。",
    )
    add_para(
        doc,
        "需要说明的是：旁路独立计量通道输出的Q1用于管理校验和线索发现；涉及贸易结算或法定计量争议的，仍以依法检定或校准的计量器具结论为准。外夹式核查传感器及其积算单元应按相应计量管理要求定期校准。",
    )
    add_para(
        doc,
        "本实施例中，相对偏差阈值、采样周期、容差窗天数均可配置，不构成对权利要求的额外限定。凡采用旁路独立计量、原监测只听镜像与业务水量在加装控制器内自动闭合的同等实现，均落入本发明精神范围。",
    )

    # ===== 附图页 =====
    doc.add_page_break()
    add_heading_cn(doc, "说 明 书 附 图", 16)
    add_figure(doc, figs["fig1"], "图1  取水计量三方数据校验加装装置结构示意图")
    add_figure(doc, figs["fig2"], "图2  故障直通只听分接单元原理示意图")
    doc.add_page_break()
    add_figure(doc, figs["fig3"], "图3  三方数据校验方法流程图")
    add_figure(doc, figs["fig4"], "图4  校验控制器模块组成框图")

    # ===== 摘要 =====
    doc.add_page_break()
    add_heading_cn(doc, "说 明 书 摘 要", 16)
    add_para(
        doc,
        "本发明公开一种取水计量三方数据校验加装装置及校验方法。装置包括固定加装的外夹式旁路独立计量通道、串接于原流量计与原遥测终端之间的故障直通只听分接单元、校验控制器和业务数据接口。旁路通道获得独立水量Q1，只听分接获得原监测镜像水量Q2，业务接口输入直报水量和/或纳税水量及许可约束；控制器在统一时基下比对Q1与Q2，并在业务周期内完成与申报水量的偏差判别，超阈值或强制违规时生成校验事件。本发明可在不拆除原表、不影响原远传的条件下实现常驻三方校验，区分监测链路异常与申报不一致问题。",
        first_line=True,
    )
    add_para(doc, "摘要附图：图1", first_line=False)
    add_figure(doc, figs["fig1"], "摘要附图（图1）")

    # 附件：附图标记列表
    doc.add_page_break()
    add_heading_cn(doc, "附：附图标记列表", 14)
    for line in [
        "1  原流量计",
        "2  外夹式核查传感器",
        "3  故障直通只听分接单元",
        "4  原遥测终端",
        "5  校验控制器",
        "6  业务数据接口",
        "51 同步采集与对账模块",
        "52 存储与事件输出模块",
        "Q1 旁路独立计量水量",
        "Q2 原监测镜像水量",
        "Q3a 直报水量",
        "Q3b 纳税水量",
    ]:
        add_para(doc, line, first_line=False, space_after=2)

    out = OUT_DIR / "取水计量三方数据校验加装装置_专利申请撰写材料.docx"
    doc.save(out)
    # also copy to private and artifacts if exists
    alt = ALT_DIR / out.name
    doc.save(alt)
    artifacts = Path("/opt/cursor/artifacts")
    if artifacts.exists():
        doc.save(artifacts / out.name)
    return out


def main():
    FIG_DIR.mkdir(parents=True, exist_ok=True)
    OUT_DIR.mkdir(parents=True, exist_ok=True)
    figs = {
        "fig1": fig1_system(),
        "fig2": fig2_tap(),
        "fig3": fig3_flow(),
        "fig4": fig4_controller(),
    }
    out = build_doc(figs)
    print(out)
    print(out.stat().st_size)


if __name__ == "__main__":
    main()
