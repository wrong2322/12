三方数据校验 — 专利 / 多模型 / 设备材料打包说明
================================================

本压缩包不含申报原稿与真实台账（隐私隔离）。

目录：
01_专利撰写材料
  - 取水计量三方数据校验加装装置_专利申请撰写材料.docx（主交付）
  - fig1～fig4 说明书附图
  - gen_patent_docx.py（生成脚本，可选）

02_多模型与编排
  - config/models.yaml、thresholds.yaml
  - prompts/ 五角色提示词
  - src/ 规则引擎、模型适配、编排器、CLI

03_加装设备方案
  - addon/  主方案 TVD-Gate（现场加装常驻三方校验）
  - 便携辅具_TVD300/  比测巡检辅具（非主方案）

04_流程材料
  - PLAYBOOK、SOP、表单、检查清单等

05_样例与原型代码
  - 脱敏样例 JSON 与单元测试

运行原型（可选）：
  cd 02_多模型与编排
  python3 -m venv .venv && source .venv/bin/activate
  pip install -r requirements.txt
  python src/cli.py ../05_样例与原型代码/samples/households_demo.json
